﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlackjackModel;

/* Written by Brian Bird
 * July 30, 2013
 * Revised August 1, 2013 */

namespace BlackjackTests
{

    
    class Program
    {
        const bool CARD_TESTS = false;
        const bool DECK_HAND_TESTS = false;
        const bool PLAYER_TESTS = false;
        const bool DEALER_TESTS = false;
        const bool CONSOLE_GAME = true;

        static void Main(string[] args)
        {
            #region Deck and Hand tests
            if (DECK_HAND_TESTS)
            {
                // Some quick tests
                Deck myDeck = new Deck();
                myDeck.Shuffle();
                Hand myHand = null;

                Card myCard = null;
                for (int i = 0; i < 4; i++)
                {
                    myHand = new Hand(); ;
                    // Put  cards in a hand
                    while (!(myHand.CalcLowScore() < Hand.BLACKJACK))
                    {
                        myCard = myDeck.GetCard();
                        Console.WriteLine("value: {0}, suit: {1}", myCard.Value, myCard.Suit);
                        myHand.AddCard(myCard);
                    }
                    Console.WriteLine("HighScore for hand: {0}", myHand.CalcHighScore());
                    Console.WriteLine("LowScore for hand: {0}", myHand.CalcLowScore());
                }

                // Make a contrived hand for testing high and low score methods
                myHand = new Hand();
                myCard = new Card('h', 'a');
                Console.WriteLine("value: {0}, suit: {1}", myCard.Value, myCard.Suit);
                myHand.AddCard(myCard);
                myCard = new Card('s', 'a');
                Console.WriteLine("value: {0}, suit: {1}", myCard.Value, myCard.Suit);
                myHand.AddCard(myCard);
                myCard = new Card('c', 'a');
                Console.WriteLine("value: {0}, suit: {1}", myCard.Value, myCard.Suit);
                myHand.AddCard(myCard);
                myCard = new Card('c', '2');
                Console.WriteLine("value: {0}, suit: {1}", myCard.Value, myCard.Suit);
                myHand.AddCard(myCard);
                myCard = new Card('s', '2');
                Console.WriteLine("value: {0}, suit: {1}", myCard.Value, myCard.Suit);
                myHand.AddCard(myCard);
                Console.WriteLine("HighScore for hand: {0}", myHand.CalcHighScore());
                Console.WriteLine("LowScore for hand: {0}", myHand.CalcLowScore());
            }
            #endregion

            #region Console Game
            if(CONSOLE_GAME)
            {
                Deck deck = new Deck();
                Player player = new Player(deck);
                Dealer dealer = new Dealer(deck);

                player.Chips = 100;
                bool play = true;
                bool hit = true;

                Console.WriteLine("Blackjack Game");
                deck.Shuffle();
                while (play)
                {
                    Console.WriteLine("Beginning a new hand");
                    Console.Write("Ener your bet:");
                    player.Bet = int.Parse(Console.ReadLine());
                    player.NewHand();
                    dealer.NewHand();

                    // deal two cards
                    player.Hit();
                    dealer.Hit();
                    player.Hit();
                    dealer.Hit();

                    hit = true;
                    while (hit)
                    {
                        Console.WriteLine("Player's hand: {0}, score: {1}", player.ShowHand(), player.Score);
                        Console.WriteLine("Dealer's hand: {0}", dealer.ShowPartialHand());

                        if (!player.IsBust)
                        {
                            Console.Write("Do you want a hit? (y/n)");
                            if (Convert.ToChar(Console.ReadLine()) == 'y')
                                player.Hit();
                            else
                                hit = false;
                        }
                        else
                        {
                            Console.WriteLine("Player is bust!");
                            hit = false;
                        }

                        if (!dealer.IsBust)
                        {
                            if (dealer.Hit())
                            {
                                Console.WriteLine("The dealer took a hit");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Dealer is bust!");
                            hit = false;
                        }

                    }
                    Console.WriteLine("Player's hand: {0}, score: {1}", player.ShowHand(), player.Score);
                    Console.WriteLine("Dealer's hand: {0}, score: {1}", dealer.ShowHand(), dealer.Score);

                    if (player.Score > dealer.Score)
                    {
                        Console.WriteLine("You won!");
                        player.Win();
                    }
                    else if (player.Score == dealer.Score)
                    {
                        Console.WriteLine("It's a push");
                    }
                    else
                    {
                        Console.WriteLine("The dealer won");
                        player.Loose();
                    }
                    Console.WriteLine("You have {0} chips", player.Chips);
                    Console.Write("Do you want to play another hand? (y/n)");
                    play = Convert.ToChar(Console.ReadLine()) == 'y' ? true : false;
                }
            }
            #endregion
        }
    }
}

