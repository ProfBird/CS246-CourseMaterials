﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackjackModel
{
    public class Dealer : Player
    {
        public Dealer(Deck d) : base(d)
        {
        }

        public string ShowPartialHand()
        {
            return ShowHand().Substring(0,2) + " xx " + ShowHand().Substring(5);
        }

        public override bool Hit()
        {
            if (hand.CalcLowScore() <= 17)
                return base.Hit();
            else
                return false;
        }
    }
}
