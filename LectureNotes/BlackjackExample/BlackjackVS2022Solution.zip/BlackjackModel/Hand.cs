﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackjackModel
{
    
    public class Hand
    {
        public const int BLACKJACK = 21;
        List<Card> cards = new List<Card>();

        public bool IsBlackjack
        {
            get { return CalcLowScore() == BLACKJACK || CalcHighScore() == BLACKJACK; }
        }

        public int Count
        {
            get { return cards.Count(); }
        }

        public Card this[int i]
        {
            get
            {
                return cards[i];
            }
        }

        public void  AddCard(Card c)
        {
                cards.Add(c);
        }



        public int CalcHighScore()
        {
            int score = 0;
            foreach (Card c in cards)
            {
                switch (c.Value)
                {
                    case 'a':
                        score += 11;
                        break;
                    case 'j':
                    case 'k':
                    case 'q':
                    case 't':
                        score += 10;
                        break;
                    default:
                        score += int.Parse(c.Value.ToString());
                        break;
                }
            }

            return score;
        }

        public int CalcLowScore()
        {
            int score = CalcHighScore();
            bool firstAce = true;
            foreach (Card c in cards)
            {
                if (c.Value == 'a')
                {
                    if (!firstAce)
                    {
                        score -= 10;
                    }
                    else
                    {
                        firstAce = false;
                    }
                }
            }
            return score;
        }

        public void Clear()
        {
            cards.Clear();
        }
    }
}
