﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackjackModel
{
    public class Player
    {
        protected Hand hand = new Hand();
        private Deck deck = null;

        public int Chips { get; set; }
        public int Bet { get; set; }

        public int Score
        {
            get
            {
                int score = hand.CalcHighScore();
                if (score <= Hand.BLACKJACK)
                    return score;
                else if ((score = hand.CalcLowScore()) <= Hand.BLACKJACK)
                    return score;
                else
                    return 0;
            }
        }


        public Player()
        {
            throw new Exception("You must use the overloaded constructor.");
        }

        public Player(Deck d)
        {
            deck = d;
        }

        public bool IsBust
        {
            get { return hand.CalcLowScore() > Hand.BLACKJACK; }
        }


        public string ShowHand()
        {
            string cardCodes = "";
            for(int i = 0; i < hand.Count; i++)
                cardCodes += hand[i].CardCode + " ";

            return cardCodes;
        }

        public virtual bool Hit()
        {
            if (!IsBust)
                hand.AddCard(deck.GetCard());
            else
                return false;

            return true;
        }

        public void Win()
        { 
            Chips += Bet;
            Bet = 0;
        }

        public void Loose()
        {
            Chips -= Bet;
            Bet = 0;
        }

        public void NewHand()
        {
            hand.Clear();
        }
    }
}
