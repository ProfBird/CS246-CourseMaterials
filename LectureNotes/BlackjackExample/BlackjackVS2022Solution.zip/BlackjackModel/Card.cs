﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackjackModel
{
    public class Card
    {
        public char Suit { get; set; }
        public char Value { get; set; }

        public Card(char s, char v)
        {
            Suit = s;
            Value = v;
        }

        public string CardCode
        {
            get { return String.Format("{0}{1}", Value, Suit); }
        }
    }
}
