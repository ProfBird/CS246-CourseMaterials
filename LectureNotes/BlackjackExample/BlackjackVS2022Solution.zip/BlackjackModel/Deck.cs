﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackjackModel
{
    public class Deck
    {
        List<Card> cards = new List<Card>();
        Random rand = new Random();

        public Deck()
        {
            // TODO: Set values and suits
            char[] values = { 'a', '1', '2', '3', '4', '5', '6', '7', '8', '9', 't', 'j', 'k', 'q' };
            char[] suits = { 'd', 'h', 's', 'c' };
            foreach (char s in suits)
                foreach (char v in values)
                    cards.Add(new Card(s, v));
        }

        public void Shuffle()
        {
            Card temp = null;
            int randIndex = 0;
            for (int i = 0; i < cards.Count; i++)
            {
                // Swap the file name at cards[i] and cards[randIndex]
                temp = cards[i];
                randIndex = rand.Next(cards.Count - 1) + 1;
                cards[i] = cards[randIndex];
                cards[randIndex] = temp;
            }
        }


        public Card GetCard()
        {
            Card card = cards[cards.Count - 1];
            cards.RemoveAt(cards.Count - 1);
            return card;
        }
    }

}
